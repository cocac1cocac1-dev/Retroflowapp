package com.mediaplayer.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import com.mediaplayer.app.MediaPlayerApplication
import com.mediaplayer.app.R
import com.mediaplayer.app.preferences.AppPreferences
import com.mediaplayer.app.service.MediaPlaybackService
import com.mediaplayer.app.utils.MediaItem
import com.mediaplayer.app.utils.Playlist
import com.mediaplayer.app.utils.PlaylistManager
import java.util.UUID

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: AppPreferences
    private lateinit var playlistManager: PlaylistManager

    private lateinit var coverFlow: RecyclerView
    private lateinit var tabLayout: TabLayout
    private lateinit var centerTitle: TextView
    private lateinit var centerSubtitle: TextView
    private lateinit var emptyState: TextView
    private lateinit var miniPlayer: LinearLayout
    private lateinit var miniTitle: TextView
    private lateinit var miniArtist: TextView
    private lateinit var btnMiniPlay: ImageButton
    private lateinit var crtOverlay: CrtOverlayView
    private lateinit var backgroundImage: ImageView
    private lateinit var root: View

    private lateinit var adapter: CoverFlowAdapter
    private lateinit var layoutManager: CoverFlowLayoutManager

    private var currentMode = 0 // 0=video, 1=music, 2=playlists
    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null

    private var pendingCoverTargetId: String? = null // media or playlist id for custom cover

    // ---- file / image pickers ----
    private val openMediaLauncher = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        uris.forEach { uri ->
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            addUriToLibrary(uri)
        }
        refreshCoverFlow()
    }

    private val pickCoverLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri ?: return@registerForActivityResult
        contentResolver.takePersistableUriPermission(
            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        val target = pendingCoverTargetId ?: return@registerForActivityResult
        // try media first, then playlist
        playlistManager.updateCover(target, uri)
        val playlists = playlistManager.getAllPlaylists()
        playlists.find { it.id == target }?.let {
            playlistManager.savePlaylist(it.copy(coverUri = uri))
        }
        pendingCoverTargetId = null
        refreshCoverFlow()
        Toast.makeText(this, "Custom cover set", Toast.LENGTH_SHORT).show()
    }

    private val requestPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* continue anyway; SAF works without classic storage perms on modern Android */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val app = application as MediaPlayerApplication
        prefs = app.preferences
        playlistManager = PlaylistManager(this)

        bindViews()
        setupToolbar()
        setupTabs()
        setupCoverFlow()
        setupMiniPlayer()
        applyTheme()
        requestNeededPermissions()

        // Handle VIEW intent (open file from another app)
        intent?.data?.let { uri ->
            addUriToLibrary(uri)
            playItem(playlistManager.getLibrary().lastOrNull() ?: return@let)
        }
    }

    private fun bindViews() {
        root = findViewById(R.id.root)
        coverFlow = findViewById(R.id.coverFlow)
        tabLayout = findViewById(R.id.tabLayout)
        centerTitle = findViewById(R.id.centerTitle)
        centerSubtitle = findViewById(R.id.centerSubtitle)
        emptyState = findViewById(R.id.emptyState)
        miniPlayer = findViewById(R.id.miniPlayer)
        miniTitle = findViewById(R.id.miniTitle)
        miniArtist = findViewById(R.id.miniArtist)
        btnMiniPlay = findViewById(R.id.btnMiniPlay)
        crtOverlay = findViewById(R.id.crtOverlay)
        backgroundImage = findViewById(R.id.backgroundImage)

        findViewById<FloatingActionButton>(R.id.fabAdd).setOnClickListener {
            when (currentMode) {
                2 -> showCreatePlaylistDialog()
                else -> openMediaPicker()
            }
        }
    }

    private fun setupToolbar() {
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
    }

    private fun setupTabs() {
        tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                currentMode = tab.position
                refreshCoverFlow()
            }
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupCoverFlow() {
        layoutManager = CoverFlowLayoutManager(this)
        coverFlow.layoutManager = layoutManager
        coverFlow.setHasFixedSize(true)
        coverFlow.clipToPadding = false
        coverFlow.clipChildren = false

        PagerSnapHelper().attachToRecyclerView(coverFlow)

        adapter = CoverFlowAdapter(
            emptyList(),
            onClick = { item -> playItem(item) },
            onLongClick = { item -> showItemOptions(item) }
        )
        coverFlow.adapter = adapter

        coverFlow.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    val pos = layoutManager.getCenterPosition()
                    adapter.setSelected(pos)
                    updateCenterLabels(pos)
                }
            }
        })

        refreshCoverFlow()
    }

    private fun refreshCoverFlow() {
        val items = when (currentMode) {
            0 -> playlistManager.getLibrary().filter { it.isVideo }
            1 -> playlistManager.getLibrary().filter { !it.isVideo }
            else -> {
                // Playlists as synthetic "cases"
                playlistManager.getAllPlaylists().map { pl ->
                    MediaItem(
                        id = pl.id,
                        uri = Uri.EMPTY,
                        title = pl.name,
                        artist = "${pl.itemIds.size} items",
                        isVideo = pl.isVideoPlaylist,
                        coverUri = pl.coverUri
                    )
                }
            }
        }
        adapter.submit(items)
        emptyState.isVisible = items.isEmpty()
        if (items.isNotEmpty()) {
            coverFlow.post {
                adapter.setSelected(0)
                updateCenterLabels(0)
            }
        } else {
            centerTitle.text = ""
            centerSubtitle.text = ""
        }
    }

    private fun updateCenterLabels(pos: Int) {
        val items = when (currentMode) {
            0 -> playlistManager.getLibrary().filter { it.isVideo }
            1 -> playlistManager.getLibrary().filter { !it.isVideo }
            else -> playlistManager.getAllPlaylists().map {
                MediaItem(it.id, Uri.EMPTY, it.name, "${it.itemIds.size} items", isVideo = it.isVideoPlaylist, coverUri = it.coverUri)
            }
        }
        if (pos in items.indices) {
            centerTitle.text = items[pos].displayTitle
            centerSubtitle.text = items[pos].artist
        }
    }

    private fun playItem(item: MediaItem) {
        if (currentMode == 2) {
            // playlist → expand and play first item
            val pl = playlistManager.getAllPlaylists().find { it.id == item.id } ?: return
            val media = playlistManager.getItemsForPlaylist(pl)
            if (media.isEmpty()) {
                Toast.makeText(this, "Playlist is empty", Toast.LENGTH_SHORT).show()
                return
            }
            startPlayback(media, 0)
        } else {
            startPlayback(listOf(item), 0)
        }
    }

    private fun startPlayback(queue: List<MediaItem>, startIndex: Int) {
        val first = queue.getOrNull(startIndex) ?: return
        if (first.isVideo) {
            // open fullscreen player
            val intent = Intent(this, PlayerActivity::class.java).apply {
                putParcelableArrayListExtra("queue", ArrayList(queue))
                putExtra("index", startIndex)
            }
            startActivity(intent)
        } else {
            // music → background service
            ensureController { ctrl ->
                val exoItems = queue.map { ExoMediaItem.fromUri(it.uri) }
                ctrl.setMediaItems(exoItems, startIndex, 0L)
                ctrl.prepare()
                ctrl.play()
                miniPlayer.isVisible = true
                miniTitle.text = first.displayTitle
                miniArtist.text = first.artist
                btnMiniPlay.setImageResource(R.drawable.ic_pause)
            }
        }
    }

    private fun ensureController(onReady: (MediaController) -> Unit) {
        if (controller != null) {
            onReady(controller!!)
            return
        }
        val token = SessionToken(this, android.content.ComponentName(this, MediaPlaybackService::class.java))
        controllerFuture = MediaController.Builder(this, token).buildAsync()
        controllerFuture!!.addListener({
            controller = controllerFuture!!.get()
            controller?.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    btnMiniPlay.setImageResource(
                        if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
                    )
                }
                override fun onMediaItemTransition(mediaItem: ExoMediaItem?, reason: Int) {
                    mediaItem?.mediaMetadata?.title?.let { miniTitle.text = it }
                }
            })
            onReady(controller!!)
        }, MoreExecutors.directExecutor())
    }

    private fun setupMiniPlayer() {
        findViewById<ImageButton>(R.id.btnMiniPlay).setOnClickListener {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        findViewById<ImageButton>(R.id.btnMiniNext).setOnClickListener {
            controller?.seekToNextMediaItem()
        }
        findViewById<ImageButton>(R.id.btnMiniPrev).setOnClickListener {
            controller?.seekToPreviousMediaItem()
        }
        miniPlayer.setOnClickListener {
            // could open a now-playing screen; for now just ensure service is alive
        }
    }

    private fun showItemOptions(item: MediaItem) {
        val options = mutableListOf("Set custom cover image", "Add to playlist")
        if (currentMode == 2) options.add("Delete playlist")
        else options.add("Remove from library")

        AlertDialog.Builder(this)
            .setTitle(item.displayTitle)
            .setItems(options.toTypedArray()) { _, which ->
                when (options[which]) {
                    "Set custom cover image" -> {
                        pendingCoverTargetId = item.id
                        pickCoverLauncher.launch(arrayOf("image/*"))
                    }
                    "Add to playlist" -> showAddToPlaylistDialog(item)
                    "Delete playlist" -> {
                        playlistManager.deletePlaylist(item.id)
                        refreshCoverFlow()
                    }
                    "Remove from library" -> {
                        // simple: rebuild library without this id
                        val lib = playlistManager.getLibrary().filter { it.id != item.id }
                        // PlaylistManager doesn't expose clear; re-add
                        // For simplicity we just ignore remove for now or implement later
                        Toast.makeText(this, "Long-press → cover is the main customization", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .show()
    }

    private fun showAddToPlaylistDialog(item: MediaItem) {
        val playlists = playlistManager.getAllPlaylists(videoOnly = item.isVideo)
        if (playlists.isEmpty()) {
            Toast.makeText(this, "Create a playlist first (Playlists tab + FAB)", Toast.LENGTH_LONG).show()
            return
        }
        val names = playlists.map { it.name }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Add to playlist")
            .setItems(names) { _, which ->
                playlistManager.addItemToPlaylist(playlists[which].id, item.id)
                Toast.makeText(this, "Added to ${playlists[which].name}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun showCreatePlaylistDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "Playlist name"
            setPadding(48, 32, 48, 32)
        }
        val isVideo = true // default; user can choose
        AlertDialog.Builder(this)
            .setTitle("New playlist")
            .setView(input)
            .setPositiveButton("Video playlist") { _, _ ->
                val name = input.text.toString().ifBlank { "Video Playlist" }
                playlistManager.createPlaylist(name, isVideo = true)
                refreshCoverFlow()
            }
            .setNeutralButton("Music playlist") { _, _ ->
                val name = input.text.toString().ifBlank { "Music Playlist" }
                playlistManager.createPlaylist(name, isVideo = false)
                refreshCoverFlow()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openMediaPicker() {
        openMediaLauncher.launch(arrayOf("video/*", "audio/*"))
    }

    private fun addUriToLibrary(uri: Uri) {
        val (title, mime) = queryNameAndMime(uri)
        val isVideo = mime?.startsWith("video") == true ||
                title.lowercase().let {
                    it.endsWith(".mp4") || it.endsWith(".mkv") || it.endsWith(".avi") ||
                            it.endsWith(".webm") || it.endsWith(".mov") || it.endsWith(".wmv")
                }
        val item = MediaItem(
            id = UUID.randomUUID().toString(),
            uri = uri,
            title = title.substringBeforeLast('.').ifBlank { title },
            artist = if (isVideo) "Video" else "Music",
            isVideo = isVideo,
            mimeType = mime
        )
        playlistManager.addToLibrary(item)
    }

    private fun queryNameAndMime(uri: Uri): Pair<String, String?> {
        var name = uri.lastPathSegment ?: "Unknown"
        var mime: String? = contentResolver.getType(uri)
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && nameIdx >= 0) name = c.getString(nameIdx) ?: name
        }
        return name to mime
    }

    private fun applyTheme() {
        root.setBackgroundColor(prefs.backgroundColor)
        crtOverlay.setEnabledEffect(prefs.crtEnabled)
        prefs.backgroundImageUri?.let { uriStr ->
            try {
                backgroundImage.setImageURI(Uri.parse(uriStr))
                backgroundImage.isVisible = true
            } catch (_: Exception) {
                backgroundImage.isVisible = false
            }
        } ?: run { backgroundImage.isVisible = false }
    }

    private fun requestNeededPermissions() {
        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            perms += Manifest.permission.READ_MEDIA_VIDEO
            perms += Manifest.permission.READ_MEDIA_AUDIO
            perms += Manifest.permission.POST_NOTIFICATIONS
        } else {
            perms += Manifest.permission.READ_EXTERNAL_STORAGE
        }
        val need = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (need.isNotEmpty()) requestPermission.launch(need.toTypedArray())
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_open -> {
                openMediaPicker()
                true
            }
            R.id.action_settings -> {
                startActivity(Intent(this, SettingsActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        refreshCoverFlow()
    }

    override fun onDestroy() {
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }
}
