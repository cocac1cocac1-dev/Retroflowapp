package com.mediaplayer.app.ui

import android.content.Context
import android.graphics.*
import android.graphics.drawable.Drawable
import android.net.Uri
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.mediaplayer.app.R
import kotlin.math.min

/**
 * Draws a 3D-looking DVD case (video) or CD jewel case (music).
 * Supports custom cover art via setCoverUri / setCoverBitmap.
 */
class CaseCoverView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    enum class CaseType { DVD, CD }

    var caseType: CaseType = CaseType.DVD
        set(value) {
            field = value
            invalidate()
        }

    private var coverBitmap: Bitmap? = null
    private var titleText: String = ""
    private var selected = false

    private val casePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spinePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(90, 0, 0, 0)
        maskFilter = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL)
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        color = Color.WHITE
    }

    private val plasticColor = Color.parseColor("#E8E8F0")
    private val spineColor = Color.parseColor("#C0C0D0")
    private val dvdTrayColor = Color.parseColor("#1A1A2E")

    fun setCoverUri(uri: Uri?) {
        coverBitmap = null
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    coverBitmap = BitmapFactory.decodeStream(stream)
                }
            } catch (_: Exception) { /* ignore */ }
        }
        invalidate()
    }

    fun setCoverBitmap(bmp: Bitmap?) {
        coverBitmap = bmp
        invalidate()
    }

    fun setTitle(title: String) {
        titleText = title
        invalidate()
    }

    fun setSelectedState(sel: Boolean) {
        selected = sel
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return

        // drop shadow
        canvas.drawRoundRect(12f, 18f, w - 4f, h - 4f, 8f, 8f, shadowPaint)

        when (caseType) {
            CaseType.DVD -> drawDvdCase(canvas, w, h)
            CaseType.CD -> drawCdCase(canvas, w, h)
        }

        if (selected) {
            borderPaint.color = Color.parseColor("#E94560")
            borderPaint.strokeWidth = 5f
            canvas.drawRoundRect(4f, 4f, w - 8f, h - 8f, 10f, 10f, borderPaint)
        }
    }

    private fun drawDvdCase(canvas: Canvas, w: Float, h: Float) {
        // outer plastic
        casePaint.color = plasticColor
        canvas.drawRoundRect(4f, 4f, w - 8f, h - 8f, 6f, 6f, casePaint)

        // spine (left edge)
        val spineW = w * 0.08f
        spinePaint.color = spineColor
        canvas.drawRect(4f, 4f, 4f + spineW, h - 8f, spinePaint)

        // dark tray / disc area
        casePaint.color = dvdTrayColor
        val inset = spineW + 6f
        canvas.drawRoundRect(inset, 10f, w - 14f, h - 14f, 4f, 4f, casePaint)

        // cover art
        val artLeft = inset + 4f
        val artTop = 14f
        val artRight = w - 18f
        val artBottom = h - 18f
        drawCover(canvas, artLeft, artTop, artRight, artBottom)

        // title if no cover
        if (coverBitmap == null && titleText.isNotBlank()) {
            textPaint.textSize = min(w, h) * 0.07f
            val lines = titleText.chunked(18).take(3)
            var ty = h * 0.4f
            lines.forEach { line ->
                canvas.drawText(line, (artLeft + artRight) / 2, ty, textPaint)
                ty += textPaint.textSize * 1.3f
            }
        }
    }

    private fun drawCdCase(canvas: Canvas, w: Float, h: Float) {
        // jewel case outer (more square)
        casePaint.color = Color.parseColor("#F0F0F8")
        canvas.drawRoundRect(6f, 6f, w - 10f, h - 10f, 4f, 4f, casePaint)

        // hinge / spine
        val spineW = w * 0.06f
        spinePaint.color = Color.parseColor("#B8B8C8")
        canvas.drawRect(6f, 6f, 6f + spineW, h - 10f, spinePaint)

        // booklet / front insert area
        casePaint.color = Color.parseColor("#222233")
        val inset = spineW + 8f
        canvas.drawRect(inset, 12f, w - 16f, h - 16f, casePaint)

        drawCover(canvas, inset + 2f, 14f, w - 18f, h - 18f)

        if (coverBitmap == null && titleText.isNotBlank()) {
            textPaint.textSize = min(w, h) * 0.065f
            canvas.drawText(
                titleText.take(20),
                (inset + w - 16f) / 2,
                h * 0.5f,
                textPaint
            )
        }
    }

    private fun drawCover(canvas: Canvas, left: Float, top: Float, right: Float, bottom: Float) {
        val bmp = coverBitmap
        if (bmp != null && !bmp.isRecycled) {
            val src = Rect(0, 0, bmp.width, bmp.height)
            val dst = RectF(left, top, right, bottom)
            canvas.drawBitmap(bmp, src, dst, null)
        } else {
            // placeholder gradient
            val grad = LinearGradient(
                left, top, right, bottom,
                Color.parseColor("#2A2A4A"),
                Color.parseColor("#1A1A2E"),
                Shader.TileMode.CLAMP
            )
            casePaint.shader = grad
            canvas.drawRect(left, top, right, bottom, casePaint)
            casePaint.shader = null
        }
    }
}
