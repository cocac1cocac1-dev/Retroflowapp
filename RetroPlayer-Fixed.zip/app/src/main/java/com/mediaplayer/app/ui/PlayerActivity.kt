package com.mediaplayer.app.ui

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.google.android.material.slider.Slider
import com.mediaplayer.app.MediaPlayerApplication
import com.mediaplayer.app.R
import com.mediaplayer.app.preferences.AppPreferences
import com.mediaplayer.app.utils.MediaItem
import java.util.concurrent.TimeUnit

class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: ZoomablePlayerView
    private lateinit var controls: View
    private lateinit var titleText: TextView
    private lateinit var positionText: TextView
    private lateinit var durationText: TextView
    private lateinit var progressSlider: Slider
    private lateinit var btnPlay: ImageButton
    private lateinit var crtOverlay: CrtOverlayView
    private lateinit var prefs: AppPreferences

    private val handler = Handler(Looper.getMainLooper())
    private var queue: List<MediaItem> = emptyList()
    private var index = 0
    private var controlsVisible = true
    private var userSeeking = false

    private val hideControlsRunnable = Runnable { setControlsVisible(false) }
    private val updateProgressRunnable = object : Runnable {
        override fun run() {
            player?.let { p ->
                if (!userSeeking && p.duration > 0) {
                    val pos = p.currentPosition.toFloat()
                    val dur = p.duration.toFloat()
                    progressSlider.valueTo = dur.coerceAtLeast(1f)
                    progressSlider.value = pos.coerceIn(0f, progressSlider.valueTo)
                    positionText.text = formatTime(p.currentPosition)
                    durationText.text = formatTime(p.duration)
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        prefs = (application as MediaPlayerApplication).preferences

        @Suppress("DEPRECATION")
        queue = intent.getParcelableArrayListExtra<MediaItem>("queue") ?: emptyList()
        index = intent.getIntExtra("index", 0)

        bindViews()
        setupPlayer()
        applyCrt()
        if (prefs.keepScreenOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun bindViews() {
        playerView = findViewById(R.id.playerView)
        controls = findViewById(R.id.controlsContainer)
        titleText = findViewById(R.id.titleText)
        positionText = findViewById(R.id.positionText)
        durationText = findViewById(R.id.durationText)
        progressSlider = findViewById(R.id.progressSlider)
        btnPlay = findViewById(R.id.btnPlay)
        crtOverlay = findViewById(R.id.crtOverlay)

        findViewById<ImageButton>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(android.content.Intent(this, SettingsActivity::class.java))
        }
        findViewById<ImageButton>(R.id.btnPrev).setOnClickListener { playPrev() }
        findViewById<ImageButton>(R.id.btnNext).setOnClickListener { playNext() }
        btnPlay.setOnClickListener {
            player?.let { if (it.isPlaying) it.pause() else it.play() }
        }

        progressSlider.addOnChangeListener { _, value, fromUser ->
            if (fromUser) {
                userSeeking = true
                positionText.text = formatTime(value.toLong())
            }
        }
        progressSlider.addOnSliderTouchListener(object : Slider.OnSliderTouchListener {
            override fun onStartTrackingTouch(slider: Slider) {
                userSeeking = true
            }
            override fun onStopTrackingTouch(slider: Slider) {
                player?.seekTo(slider.value.toLong())
                userSeeking = false
            }
        })

        // tap to toggle controls
        playerView.setOnClickListener {
            setControlsVisible(!controlsVisible)
        }
        controls.setOnClickListener {
            scheduleHideControls()
        }
    }

    private fun setupPlayer() {
        val exo = ExoPlayer.Builder(this).build()
        player = exo
        playerView.player = exo

        val mediaItems = queue.map { ExoMediaItem.fromUri(it.uri) }
        exo.setMediaItems(mediaItems, index, 0L)
        exo.prepare()
        exo.play()

        exo.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                btnPlay.setImageResource(
                    if (isPlaying) R.drawable.ic_pause else R.drawable.ic_play
                )
            }
            override fun onMediaItemTransition(mediaItem: ExoMediaItem?, reason: Int) {
                index = exo.currentMediaItemIndex
                updateTitle()
                playerView.resetZoom()
            }
        })

        updateTitle()
        handler.post(updateProgressRunnable)
        scheduleHideControls()
    }

    private fun updateTitle() {
        val item = queue.getOrNull(index)
        titleText.text = item?.displayTitle ?: getString(R.string.now_playing)
    }

    private fun playNext() {
        player?.seekToNextMediaItem()
    }

    private fun playPrev() {
        player?.seekToPreviousMediaItem()
    }

    private fun setControlsVisible(visible: Boolean) {
        controlsVisible = visible
        controls.animate()
            .alpha(if (visible) 1f else 0f)
            .setDuration(200)
            .withEndAction {
                controls.isVisible = visible
            }
            .start()
        if (visible) scheduleHideControls()
        else handler.removeCallbacks(hideControlsRunnable)
    }

    private fun scheduleHideControls() {
        handler.removeCallbacks(hideControlsRunnable)
        handler.postDelayed(hideControlsRunnable, 4000)
    }

    private fun applyCrt() {
        crtOverlay.setEnabledEffect(prefs.crtEnabled)
    }

    private fun formatTime(ms: Long): String {
        val totalSec = TimeUnit.MILLISECONDS.toSeconds(ms)
        val m = totalSec / 60
        val s = totalSec % 60
        return "%d:%02d".format(m, s)
    }

    override fun onResume() {
        super.onResume()
        applyCrt()
        player?.play()
    }

    override fun onPause() {
        super.onPause()
        // videos pause when leaving; music uses the service
        player?.pause()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        playerView.player = null
        player?.release()
        player = null
        super.onDestroy()
    }
}
