package com.mediaplayer.app.ui

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.materialswitch.MaterialSwitch
import com.mediaplayer.app.MediaPlayerApplication
import com.mediaplayer.app.R
import com.mediaplayer.app.preferences.AppPreferences

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: AppPreferences

    private val pickBgImage = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri ?: return@registerForActivityResult
        contentResolver.takePersistableUriPermission(
            uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        prefs.backgroundImageUri = uri.toString()
        Toast.makeText(this, "Background image set", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        prefs = (application as MediaPlayerApplication).preferences

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.setNavigationOnClickListener { finish() }

        // CRT
        val switchCrt = findViewById<MaterialSwitch>(R.id.switchCrt)
        switchCrt.isChecked = prefs.crtEnabled
        switchCrt.setOnCheckedChangeListener { _, checked ->
            prefs.crtEnabled = checked
        }

        // Keep screen on
        val switchScreen = findViewById<MaterialSwitch>(R.id.switchKeepScreenOn)
        switchScreen.isChecked = prefs.keepScreenOn
        switchScreen.setOnCheckedChangeListener { _, checked ->
            prefs.keepScreenOn = checked
        }

        // Background playback
        val switchBg = findViewById<MaterialSwitch>(R.id.switchBgPlayback)
        switchBg.isChecked = prefs.backgroundPlayback
        switchBg.setOnCheckedChangeListener { _, checked ->
            prefs.backgroundPlayback = checked
        }

        // Color previews
        updateSwatch(findViewById(R.id.previewPrimary), prefs.primaryColor)
        updateSwatch(findViewById(R.id.previewAccent), prefs.accentColor)
        updateSwatch(findViewById(R.id.previewBg), prefs.backgroundColor)

        findViewById<android.view.View>(R.id.rowPrimaryColor).setOnClickListener {
            showColorPicker("Primary color") { color ->
                prefs.primaryColor = color
                updateSwatch(findViewById(R.id.previewPrimary), color)
            }
        }
        findViewById<android.view.View>(R.id.rowAccentColor).setOnClickListener {
            showColorPicker("Accent color") { color ->
                prefs.accentColor = color
                updateSwatch(findViewById(R.id.previewAccent), color)
            }
        }
        findViewById<android.view.View>(R.id.rowBgColor).setOnClickListener {
            showColorPicker("Background color") { color ->
                prefs.backgroundColor = color
                updateSwatch(findViewById(R.id.previewBg), color)
            }
        }

        findViewById<MaterialButton>(R.id.btnChooseBgImage).setOnClickListener {
            pickBgImage.launch(arrayOf("image/*"))
        }
        findViewById<MaterialButton>(R.id.btnClearBgImage).setOnClickListener {
            prefs.backgroundImageUri = null
            Toast.makeText(this, "Background image cleared", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateSwatch(view: android.view.View, color: Int) {
        val d = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            setStroke(4, Color.WHITE)
        }
        view.background = d
    }

    private fun showColorPicker(title: String, onPick: (Int) -> Unit) {
        val colors = intArrayOf(
            Color.parseColor("#1A1A2E"),
            Color.parseColor("#16213E"),
            Color.parseColor("#0F3460"),
            Color.parseColor("#E94560"),
            Color.parseColor("#533483"),
            Color.parseColor("#00ADB5"),
            Color.parseColor("#222831"),
            Color.parseColor("#393E46"),
            Color.parseColor("#FF5722"),
            Color.parseColor("#4CAF50"),
            Color.parseColor("#2196F3"),
            Color.parseColor("#9C27B0"),
            Color.parseColor("#000000"),
            Color.parseColor("#FFFFFF"),
            Color.parseColor("#FFC107"),
            Color.parseColor("#795548")
        )
        val names = arrayOf(
            "Deep navy", "Ocean", "Midnight", "Hot pink",
            "Purple", "Teal", "Charcoal", "Slate",
            "Orange", "Green", "Blue", "Violet",
            "Black", "White", "Amber", "Brown"
        )
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(names) { _, which ->
                onPick(colors[which])
            }
            .show()
    }
}
