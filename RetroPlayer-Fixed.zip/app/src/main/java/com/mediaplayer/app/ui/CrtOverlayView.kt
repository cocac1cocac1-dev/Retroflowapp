package com.mediaplayer.app.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/**
 * Lightweight CRT / scanline overlay.
 * Toggle visibility from settings.
 */
class CrtOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : View(context, attrs, defStyle) {

    private val scanlinePaint = Paint().apply {
        color = Color.argb(40, 0, 0, 0)
        strokeWidth = 2f
        isAntiAlias = false
    }

    private val vignettePaint = Paint().apply {
        color = Color.argb(80, 0, 0, 0)
        style = Paint.Style.STROKE
        strokeWidth = 80f
        isAntiAlias = true
    }

    private val glowPaint = Paint().apply {
        color = Color.argb(15, 233, 69, 96)
        style = Paint.Style.FILL
    }

    private var lineSpacing = 4f

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()

        // subtle overall tint
        canvas.drawRect(0f, 0f, w, h, glowPaint)

        // horizontal scanlines
        var y = 0f
        while (y < h) {
            canvas.drawLine(0f, y, w, y, scanlinePaint)
            y += lineSpacing
        }

        // vignette / edge darkening (cheap approximation of CRT curvature)
        vignettePaint.strokeWidth = w * 0.12f
        canvas.drawRect(0f, 0f, w, h, vignettePaint)
    }

    fun setEnabledEffect(enabled: Boolean) {
        visibility = if (enabled) VISIBLE else GONE
        if (enabled) invalidate()
    }
}
