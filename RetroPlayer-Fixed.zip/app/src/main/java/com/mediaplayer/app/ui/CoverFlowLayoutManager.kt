package com.mediaplayer.app.ui

import android.content.Context
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlin.math.abs
import kotlin.math.min

/**
 * Horizontal layout that applies PS3-style 3D depth:
 * - center item is largest / front
 * - side items rotate in Y and shrink
 */
class CoverFlowLayoutManager(context: Context) :
    LinearLayoutManager(context, HORIZONTAL, false) {

    private var recyclerView: RecyclerView? = null

    override fun onAttachedToWindow(view: RecyclerView?) {
        super.onAttachedToWindow(view)
        recyclerView = view
    }

    override fun scrollHorizontallyBy(
        dx: Int,
        recycler: RecyclerView.Recycler?,
        state: RecyclerView.State?
    ): Int {
        val scrolled = super.scrollHorizontallyBy(dx, recycler, state)
        applyTransforms()
        return scrolled
    }

    override fun onLayoutCompleted(state: RecyclerView.State?) {
        super.onLayoutCompleted(state)
        applyTransforms()
    }

    private fun applyTransforms() {
        val rv = recyclerView ?: return
        val mid = rv.width / 2f
        for (i in 0 until childCount) {
            val child = getChildAt(i) ?: continue
            val childMid = (getDecoratedLeft(child) + getDecoratedRight(child)) / 2f
            val distance = (childMid - mid) / mid   // -1 … +1

            // scale: 1.0 at center → 0.7 at edges
            val scale = 1f - 0.3f * min(1f, abs(distance))
            child.scaleX = scale
            child.scaleY = scale

            // Y rotation for 3D case effect
            child.rotationY = distance * -35f

            // slight Z translation (elevation)
            child.translationZ = (1f - abs(distance)) * 40f

            // alpha
            child.alpha = 0.55f + 0.45f * (1f - min(1f, abs(distance)))
        }
    }

    fun getCenterPosition(): Int {
        val rv = recyclerView ?: return 0
        val mid = rv.width / 2
        var closest = 0
        var minDist = Int.MAX_VALUE
        for (i in 0 until childCount) {
            val child = getChildAt(i) ?: continue
            val childMid = (getDecoratedLeft(child) + getDecoratedRight(child)) / 2
            val dist = abs(childMid - mid)
            if (dist < minDist) {
                minDist = dist
                closest = getPosition(child)
            }
        }
        return closest
    }
}
