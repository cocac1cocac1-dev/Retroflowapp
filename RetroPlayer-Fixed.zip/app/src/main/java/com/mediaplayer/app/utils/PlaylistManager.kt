package com.mediaplayer.app.utils

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Simple local playlist store using SharedPreferences + JSON.
 * Supports separate music & video playlists and custom cover images.
 */
class PlaylistManager(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getAllPlaylists(videoOnly: Boolean? = null): List<Playlist> {
        val json = prefs.getString(KEY_PLAYLISTS, "[]") ?: "[]"
        val arr = JSONArray(json)
        val list = mutableListOf<Playlist>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val isVideo = obj.optBoolean("isVideo", false)
            if (videoOnly != null && isVideo != videoOnly) continue
            list.add(
                Playlist(
                    id = obj.getString("id"),
                    name = obj.getString("name"),
                    isVideoPlaylist = isVideo,
                    itemIds = obj.optJSONArray("items")?.let { a ->
                        MutableList(a.length()) { a.getString(it) }
                    } ?: mutableListOf(),
                    coverUri = obj.optString("cover", null)?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
                )
            )
        }
        return list
    }

    fun savePlaylist(playlist: Playlist) {
        val all = getAllPlaylists().toMutableList()
        val idx = all.indexOfFirst { it.id == playlist.id }
        if (idx >= 0) all[idx] = playlist else all.add(playlist)
        writeAll(all)
    }

    fun deletePlaylist(id: String) {
        writeAll(getAllPlaylists().filter { it.id != id })
    }

    fun createPlaylist(name: String, isVideo: Boolean, cover: Uri? = null): Playlist {
        val p = Playlist(
            id = UUID.randomUUID().toString(),
            name = name,
            isVideoPlaylist = isVideo,
            coverUri = cover
        )
        savePlaylist(p)
        return p
    }

    fun addItemToPlaylist(playlistId: String, mediaId: String) {
        val all = getAllPlaylists().toMutableList()
        val idx = all.indexOfFirst { it.id == playlistId }
        if (idx >= 0) {
            val p = all[idx]
            if (!p.itemIds.contains(mediaId)) {
                p.itemIds.add(mediaId)
                all[idx] = p
                writeAll(all)
            }
        }
    }

    fun removeItemFromPlaylist(playlistId: String, mediaId: String) {
        val all = getAllPlaylists().toMutableList()
        val idx = all.indexOfFirst { it.id == playlistId }
        if (idx >= 0) {
            val p = all[idx]
            p.itemIds.remove(mediaId)
            all[idx] = p
            writeAll(all)
        }
    }

    // ---- Media library (scanned / opened files) ----

    fun getLibrary(): List<MediaItem> {
        val json = prefs.getString(KEY_LIBRARY, "[]") ?: "[]"
        val arr = JSONArray(json)
        val list = mutableListOf<MediaItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                MediaItem(
                    id = o.getString("id"),
                    uri = Uri.parse(o.getString("uri")),
                    title = o.optString("title", "Unknown"),
                    artist = o.optString("artist", "Unknown Artist"),
                    durationMs = o.optLong("duration", 0L),
                    isVideo = o.optBoolean("isVideo", false),
                    mimeType = o.optString("mime", null),
                    coverUri = o.optString("cover", null)?.takeIf { it.isNotBlank() }?.let { Uri.parse(it) },
                    album = o.optString("album", null)
                )
            )
        }
        return list
    }

    fun addToLibrary(item: MediaItem) {
        val lib = getLibrary().toMutableList()
        if (lib.none { it.id == item.id || it.uri == item.uri }) {
            lib.add(item)
            writeLibrary(lib)
        }
    }

    fun updateCover(mediaId: String, coverUri: Uri?) {
        val lib = getLibrary().toMutableList()
        val idx = lib.indexOfFirst { it.id == mediaId }
        if (idx >= 0) {
            lib[idx] = lib[idx].copy(coverUri = coverUri)
            writeLibrary(lib)
        }
    }

    fun getMediaById(id: String): MediaItem? = getLibrary().find { it.id == id }

    fun getItemsForPlaylist(playlist: Playlist): List<MediaItem> {
        val lib = getLibrary().associateBy { it.id }
        return playlist.itemIds.mapNotNull { lib[it] }
    }

    private fun writeAll(list: List<Playlist>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("isVideo", p.isVideoPlaylist)
                put("items", JSONArray(p.itemIds))
                put("cover", p.coverUri?.toString() ?: "")
            })
        }
        prefs.edit().putString(KEY_PLAYLISTS, arr.toString()).apply()
    }

    private fun writeLibrary(list: List<MediaItem>) {
        val arr = JSONArray()
        list.forEach { m ->
            arr.put(JSONObject().apply {
                put("id", m.id)
                put("uri", m.uri.toString())
                put("title", m.title)
                put("artist", m.artist)
                put("duration", m.durationMs)
                put("isVideo", m.isVideo)
                put("mime", m.mimeType ?: "")
                put("cover", m.coverUri?.toString() ?: "")
                put("album", m.album ?: "")
            })
        }
        prefs.edit().putString(KEY_LIBRARY, arr.toString()).apply()
    }

    companion object {
        private const val PREFS = "playlist_store"
        private const val KEY_PLAYLISTS = "playlists"
        private const val KEY_LIBRARY = "library"
    }
}
