package com.mediaplayer.app.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.mediaplayer.app.R
import com.mediaplayer.app.utils.MediaItem

class CoverFlowAdapter(
    private var items: List<MediaItem>,
    private val onClick: (MediaItem) -> Unit,
    private val onLongClick: (MediaItem) -> Unit
) : RecyclerView.Adapter<CoverFlowAdapter.Holder>() {

    private var selectedPos = RecyclerView.NO_POSITION

    fun submit(list: List<MediaItem>) {
        items = list
        notifyDataSetChanged()
    }

    fun setSelected(position: Int) {
        val old = selectedPos
        selectedPos = position
        if (old != RecyclerView.NO_POSITION) notifyItemChanged(old)
        if (position != RecyclerView.NO_POSITION) notifyItemChanged(position)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_case_cover, parent, false)
        return Holder(v)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val item = items[position]
        holder.caseView.caseType =
            if (item.isVideo) CaseCoverView.CaseType.DVD else CaseCoverView.CaseType.CD
        holder.caseView.setTitle(item.displayTitle)
        holder.caseView.setCoverUri(item.coverUri)
        holder.caseView.setSelectedState(position == selectedPos)
        holder.label.text = item.displayTitle

        // 3D perspective based on distance from center is applied by LayoutManager / scroll listener
        holder.itemView.setOnClickListener { onClick(item) }
        holder.itemView.setOnLongClickListener {
            onLongClick(item)
            true
        }
    }

    override fun getItemCount() = items.size

    class Holder(v: View) : RecyclerView.ViewHolder(v) {
        val caseView: CaseCoverView = v.findViewById(R.id.caseCover)
        val label: TextView = v.findViewById(R.id.caseLabel)
    }
}
