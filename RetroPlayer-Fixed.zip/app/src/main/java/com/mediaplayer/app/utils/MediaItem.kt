package com.mediaplayer.app.utils

import android.net.Uri
import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class MediaItem(
    val id: String,
    val uri: Uri,
    val title: String,
    val artist: String = "Unknown Artist",
    val durationMs: Long = 0L,
    val isVideo: Boolean,
    val mimeType: String? = null,
    val coverUri: Uri? = null,          // custom DVD/CD case art
    val album: String? = null
) : Parcelable {
    val displayTitle: String
        get() = title.ifBlank { uri.lastPathSegment ?: "Unknown" }
}

@Parcelize
data class Playlist(
    val id: String,
    val name: String,
    val isVideoPlaylist: Boolean,
    val itemIds: MutableList<String> = mutableListOf(),
    val coverUri: Uri? = null           // optional playlist cover
) : Parcelable
