package com.mediaplayer.app.preferences

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import androidx.core.content.edit

class AppPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var crtEnabled: Boolean
        get() = prefs.getBoolean(KEY_CRT, false)
        set(value) = prefs.edit { putBoolean(KEY_CRT, value) }

    var keepScreenOn: Boolean
        get() = prefs.getBoolean(KEY_KEEP_SCREEN_ON, true)
        set(value) = prefs.edit { putBoolean(KEY_KEEP_SCREEN_ON, value) }

    var backgroundPlayback: Boolean
        get() = prefs.getBoolean(KEY_BG_PLAYBACK, true)
        set(value) = prefs.edit { putBoolean(KEY_BG_PLAYBACK, value) }

    var primaryColor: Int
        get() = prefs.getInt(KEY_PRIMARY, Color.parseColor("#1A1A2E"))
        set(value) = prefs.edit { putInt(KEY_PRIMARY, value) }

    var accentColor: Int
        get() = prefs.getInt(KEY_ACCENT, Color.parseColor("#E94560"))
        set(value) = prefs.edit { putInt(KEY_ACCENT, value) }

    var backgroundColor: Int
        get() = prefs.getInt(KEY_BG_COLOR, Color.parseColor("#16213E"))
        set(value) = prefs.edit { putInt(KEY_BG_COLOR, value) }

    var backgroundImageUri: String?
        get() = prefs.getString(KEY_BG_IMAGE, null)
        set(value) = prefs.edit { putString(KEY_BG_IMAGE, value) }

    fun registerListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregisterListener(listener: SharedPreferences.OnSharedPreferenceChangeListener) {
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
    }

    companion object {
        private const val PREFS_NAME = "media_player_prefs"
        private const val KEY_CRT = "crt_enabled"
        private const val KEY_KEEP_SCREEN_ON = "keep_screen_on"
        private const val KEY_BG_PLAYBACK = "background_playback"
        private const val KEY_PRIMARY = "primary_color"
        private const val KEY_ACCENT = "accent_color"
        private const val KEY_BG_COLOR = "background_color"
        private const val KEY_BG_IMAGE = "background_image_uri"
    }
}
