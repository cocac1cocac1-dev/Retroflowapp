package com.mediaplayer.app.ui

import android.content.Context
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import androidx.media3.ui.PlayerView

/**
 * ExoPlayer PlayerView with pinch-to-zoom and double-tap reset.
 * Works on the TextureView surface.
 */
class ZoomablePlayerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : PlayerView(context, attrs, defStyle) {

    private var scaleFactor = 1f
    private var focusX = 0f
    private var focusY = 0f
    private var translateX = 0f
    private var translateY = 0f

    private val scaleDetector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                scaleFactor *= detector.scaleFactor
                scaleFactor = scaleFactor.coerceIn(1f, 5f)
                focusX = detector.focusX
                focusY = detector.focusY
                applyTransform()
                return true
            }
        })

    private val gestureDetector = GestureDetector(context,
        object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                scaleFactor = 1f
                translateX = 0f
                translateY = 0f
                applyTransform()
                return true
            }

            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                if (scaleFactor > 1.05f) {
                    translateX -= distanceX
                    translateY -= distanceY
                    // clamp so content doesn't disappear completely
                    val maxTx = width * (scaleFactor - 1) / 2
                    val maxTy = height * (scaleFactor - 1) / 2
                    translateX = translateX.coerceIn(-maxTx, maxTx)
                    translateY = translateY.coerceIn(-maxTy, maxTy)
                    applyTransform()
                    return true
                }
                return false
            }
        })

    private fun applyTransform() {
        val surface = getChildAt(0) ?: return
        surface.pivotX = focusX
        surface.pivotY = focusY
        surface.scaleX = scaleFactor
        surface.scaleY = scaleFactor
        surface.translationX = translateX
        surface.translationY = translateY
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)
        // still let the controller / parent receive events when not zooming
        return true
    }

    fun resetZoom() {
        scaleFactor = 1f
        translateX = 0f
        translateY = 0f
        applyTransform()
    }
}
