package com.mediaplayer.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.mediaplayer.app.R
import com.mediaplayer.app.service.MediaPlaybackService
import com.mediaplayer.app.ui.MainActivity
import com.google.common.util.concurrent.MoreExecutors

class MediaPlayerWidget : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        appWidgetIds.forEach { id ->
            updateWidget(context, appWidgetManager, id)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_PLAY_PAUSE, ACTION_NEXT, ACTION_PREV -> {
                // Media3 session handles transport via system; we also broadcast for local update
                val mgr = AppWidgetManager.getInstance(context)
                val ids = mgr.getAppWidgetIds(ComponentName(context, MediaPlayerWidget::class.java))
                onUpdate(context, mgr, ids)
            }
        }
    }

    companion object {
        const val ACTION_PLAY_PAUSE = "com.mediaplayer.app.ACTION_PLAY_PAUSE"
        const val ACTION_NEXT = "com.mediaplayer.app.ACTION_NEXT"
        const val ACTION_PREV = "com.mediaplayer.app.ACTION_PREV"

        fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_media_player)

            // Open app on tap
            val open = PendingIntent.getActivity(
                context, 0,
                Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, open)

            // Transport buttons → broadcast back to this receiver
            views.setOnClickPendingIntent(
                R.id.widgetPlay,
                PendingIntent.getBroadcast(
                    context, 1,
                    Intent(context, MediaPlayerWidget::class.java).setAction(ACTION_PLAY_PAUSE),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            views.setOnClickPendingIntent(
                R.id.widgetNext,
                PendingIntent.getBroadcast(
                    context, 2,
                    Intent(context, MediaPlayerWidget::class.java).setAction(ACTION_NEXT),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )
            views.setOnClickPendingIntent(
                R.id.widgetPrev,
                PendingIntent.getBroadcast(
                    context, 3,
                    Intent(context, MediaPlayerWidget::class.java).setAction(ACTION_PREV),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                )
            )

            views.setTextViewText(R.id.widgetTitle, context.getString(R.string.no_media))
            views.setTextViewText(R.id.widgetArtist, context.getString(R.string.unknown_artist))

            manager.updateAppWidget(widgetId, views)
        }

        fun refreshAll(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, MediaPlayerWidget::class.java))
            ids.forEach { updateWidget(context, mgr, it) }
        }
    }
}
