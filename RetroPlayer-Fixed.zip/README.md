# RetroPlayer (Android)

A customizable retro-style video + music player with:

- **PS3-style 3D cover flow** – scroll through DVD cases (video) and CD cases (music)
- **Custom playlists** – separate video & music playlists, also shown as 3D cases
- **Custom cover art** – long-press any case (media or playlist) → set your own image
- **Background music** – plays with screen off via Media3 foreground service
- **Any video format** – ExoPlayer / Media3 (MP4, MKV, WebM, AVI via extractors, HLS, DASH, etc.)
- **Pinch-to-zoom** – on video; double-tap to reset
- **Home screen widget** – play / pause / next / previous
- **Theme customization** – primary / accent / background colors + optional background image
- **CRT effect** – scanlines + vignette; toggle on/off in Settings (applies to UI and video)

## Requirements

- Android Studio Hedgehog (2023.1.1) or newer, or AGP 8.5+
- minSdk 26, targetSdk 34
- Kotlin 1.9+

## How to build

1. Open the `RetroPlayer` folder in Android Studio.
2. Let Gradle sync (first time may download dependencies).
3. Run on a device or emulator (API 26+).

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## Usage

| Action | How |
|--------|-----|
| Add videos / music | FAB or toolbar folder icon → system file picker |
| Browse | Tabs: **Videos** (DVD cases) · **Music** (CD cases) · **Playlists** |
| Play | Tap a case |
| Custom cover | Long-press case → **Set custom cover image** |
| New playlist | Playlists tab → FAB → name it (Video or Music) |
| Add to playlist | Long-press media → **Add to playlist** |
| CRT / colors / bg | Toolbar gear → Settings |
| Widget | Long-press home screen → Widgets → Media Player |
| Zoom video | Pinch in fullscreen player; double-tap to reset |
| Screen-off music | Automatic when playing audio (notification + media controls) |

## Project structure

```
app/src/main/java/com/mediaplayer/app/
  MediaPlayerApplication.kt
  preferences/AppPreferences.kt
  service/MediaPlaybackService.kt      # screen-off playback
  widget/MediaPlayerWidget.kt
  utils/MediaItem.kt, PlaylistManager.kt
  ui/
    MainActivity.kt                    # cover-flow browser
    PlayerActivity.kt                  # fullscreen video + zoom
    SettingsActivity.kt
    CaseCoverView.kt                   # 3D DVD / CD drawing
    CoverFlowAdapter.kt
    CoverFlowLayoutManager.kt          # perspective + scale
    ZoomablePlayerView.kt
    CrtOverlayView.kt
```

## Notes

- File access uses the Storage Access Framework (SAF); no broad storage permission required on Android 11+.
- Custom covers and background images are stored as persisted content URIs.
- Playlists and library are saved in SharedPreferences (JSON). For large libraries you may later move to Room.
- ExoPlayer supports a very wide range of formats; exotic codecs may still need device hardware support.
